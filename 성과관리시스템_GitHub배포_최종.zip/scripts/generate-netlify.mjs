import { cp, mkdir, rm, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

const outputDirectory = new URL("../netlify-drop/", import.meta.url);
const clientDirectory = new URL("../dist/client/", import.meta.url);
const workerFile = new URL("../dist/server/index.js", import.meta.url);

await rm(outputDirectory, { recursive: true, force: true });
await mkdir(outputDirectory, { recursive: true });
await cp(clientDirectory, outputDirectory, { recursive: true });

const workerUrl = pathToFileURL(workerFile.pathname);
workerUrl.searchParams.set("netlify-export", String(Date.now()));
const worker = (await import(workerUrl.href)).default;

const response = await worker.fetch(
  new Request("https://hr-performance-admin.netlify.app/", {
    headers: { accept: "text/html" },
  }),
  {
    ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) },
  },
  { waitUntil() {}, passThroughOnException() {} },
);

if (!response.ok) throw new Error(`Static page export failed: ${response.status}`);

const html = (await response.text())
  .replace('<meta name="codex-preview" content="development"/>', "")
  .replace("self.__VINEXT_RSC_PARAMS__={}", "self.__VINEXT_RSC_PARAMS__={staticExport:true}");

await writeFile(new URL("index.html", outputDirectory), html, "utf8");
await writeFile(new URL("_redirects", outputDirectory), "/* /index.html 200\n", "utf8");
await rm(new URL(".vite/", outputDirectory), { recursive: true, force: true });
await rm(new URL(".assetsignore", outputDirectory), { force: true });

console.log("Netlify upload folder generated: netlify-drop/");
