# 성과·면담 관리 관리자 시험판

팀의 성과 목표와 면담 일정·기록을 한 화면에서 관리하는 HR 관리자용 웹 시험판입니다. 로그인이나 별도 서버 없이 바로 실행되며, 입력 데이터는 사용 중인 브라우저에 자동 저장됩니다.

## 포함 기능

- 관리자 대시보드: 등록 목표, 평균 진척률, 완료 현황, 확인 필요 항목
- 성과 목표: 팀원·상태 필터, 검색, 목표 등록·상태 변경·삭제, CSV 내보내기
- 면담 관리: 월간 일정, 면담 등록, 완료 처리, 후속 행동 기록
- 팀원 현황: 개인별 평균 진척률, 목표 수, 면담 기록
- 데이터 관리: 전체 JSON 백업·복원, 샘플 데이터 초기화
- 반응형 화면: PC와 태블릿·모바일 대응

> 화면에 포함된 이름과 기록은 모두 샘플입니다.

## 가장 빠른 Netlify 배포

완성 패키지의 `netlify-drop` 폴더를 [Netlify Drop](https://app.netlify.com/drop)에 끌어다 놓으면 즉시 배포됩니다. ZIP을 받은 경우 먼저 압축을 풀고 폴더를 올리세요.

## Git 저장소 연결 배포

1. 이 프로젝트 전체를 GitHub 저장소에 올립니다.
2. Netlify에서 **Add new site → Import an existing project**를 선택합니다.
3. 저장소를 연결하면 `netlify.toml` 설정이 자동 인식됩니다.
4. Build command는 `npm run build:netlify`, Publish directory는 `netlify-drop`입니다.

필요 환경은 Node.js 22.13 이상입니다.

## 로컬 실행

```bash
npm install
npm run dev
```

표시된 로컬 주소를 브라우저에서 열어 확인합니다.

Netlify에 직접 올릴 완성 폴더를 다시 만들려면 다음 명령을 사용합니다.

```bash
npm run build:netlify
```

## 데이터 저장 범위와 운영 전 조치

현재 시험판은 브라우저의 `localStorage`에 데이터를 보관합니다. 따라서 같은 PC·같은 브라우저에서는 유지되지만, 여러 사용자가 실시간으로 같은 데이터를 공유하지는 않습니다.

실제 인사정보를 운영하기 전에는 다음 항목을 추가해야 합니다.

- 관리자·팀원 로그인 및 권한 구분
- Supabase 등 서버 데이터베이스 연결
- 전송구간 암호화와 접근기록 관리
- 개인정보 보유기간·삭제 정책 적용

## 주요 파일

```text
app/
  page.tsx        화면과 성과·면담 관리 기능
  globals.css     화이트·레드 기반 관리자 UI
  layout.tsx      페이지 제목·언어 설정
public/
  _redirects      단일 페이지 경로 처리
netlify.toml      Netlify 빌드·배포 설정
DEPLOY_GUIDE.md   비개발자용 배포 안내
netlify-drop/     Netlify Drop에 바로 올리는 완성 폴더
```

## 시험판 데이터 초기화

좌측 메뉴의 **데이터 관리 → 샘플 데이터로 초기화**를 선택하면 처음 상태로 돌아갑니다. 현재 입력 내용이 필요하면 먼저 **전체 백업 저장**을 실행하세요.
