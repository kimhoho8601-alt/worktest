"use client";

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";

type GoalStatus = "미진행" | "진행" | "종결";
type InterviewStatus = "예정" | "완료";
type Tab = "dashboard" | "goals" | "interviews" | "members";

type Member = {
  id: number;
  name: string;
  role: string;
  team: string;
  color: string;
};

type Goal = {
  id: number;
  memberId: number;
  title: string;
  category: string;
  status: GoalStatus;
  progress: number;
  dueDate: string;
  weight: number;
  note: string;
};

type Interview = {
  id: number;
  memberId: number;
  date: string;
  type: string;
  status: InterviewStatus;
  summary: string;
  nextAction: string;
};

type AppData = { members: Member[]; goals: Goal[]; interviews: Interview[] };

const STORAGE_KEY = "hr-performance-admin-v2";

const seedData: AppData = {
  members: [
    { id: 1, name: "김민서", role: "상담원", team: "사례관리팀", color: "coral" },
    { id: 2, name: "이도윤", role: "상담원", team: "사례관리팀", color: "blue" },
    { id: 3, name: "박서연", role: "치료사", team: "심리지원팀", color: "violet" },
    { id: 4, name: "최지우", role: "사무원", team: "운영지원팀", color: "green" },
    { id: 5, name: "정하람", role: "상담원", team: "사업기획팀", color: "amber" },
    { id: 6, name: "윤가온", role: "상담원", team: "사업기획팀", color: "pink" },
  ],
  goals: [
    { id: 101, memberId: 1, title: "고위험 사례 초기개입 품질 향상", category: "핵심성과", status: "진행", progress: 72, dueDate: "2026-08-31", weight: 30, note: "월 1회 사례 점검" },
    { id: 102, memberId: 1, title: "사례기록 적시성 개선", category: "업무개선", status: "종결", progress: 100, dueDate: "2026-07-15", weight: 20, note: "기록 누락 0건" },
    { id: 103, memberId: 2, title: "지역 협력기관 네트워크 강화", category: "핵심성과", status: "진행", progress: 55, dueDate: "2026-09-30", weight: 30, note: "신규 협약 3개소" },
    { id: 104, memberId: 3, title: "치료 대기기간 단축", category: "핵심성과", status: "진행", progress: 84, dueDate: "2026-08-20", weight: 35, note: "평균 대기 10일 이내" },
    { id: 105, memberId: 4, title: "월별 예산 집행 점검 자동화", category: "업무개선", status: "미진행", progress: 10, dueDate: "2026-08-10", weight: 25, note: "공통 양식 적용" },
    { id: 106, memberId: 5, title: "아동권리 교육 참여 확대", category: "사업성과", status: "진행", progress: 63, dueDate: "2026-10-31", weight: 30, note: "전년 대비 15% 확대" },
    { id: 107, memberId: 6, title: "외부 요청자료 표준화", category: "업무개선", status: "미진행", progress: 20, dueDate: "2026-08-05", weight: 20, note: "제출 양식 3종 정비" },
  ],
  interviews: [
    { id: 201, memberId: 1, date: "2026-07-22T10:00:00+09:00", type: "정기 1:1", status: "예정", summary: "2분기 목표 진척 점검", nextAction: "사례 배분 현황 확인" },
    { id: 202, memberId: 3, date: "2026-07-23T15:00:00+09:00", type: "성장 면담", status: "예정", summary: "전문교육 및 역할 확대 논의", nextAction: "교육과정 후보 공유" },
    { id: 203, memberId: 4, date: "2026-07-16T11:00:00+09:00", type: "정기 1:1", status: "완료", summary: "예산 점검 자동화 범위 합의", nextAction: "8월 1주차 초안 확인" },
    { id: 204, memberId: 2, date: "2026-07-18T14:00:00+09:00", type: "수시 면담", status: "완료", summary: "협력기관 대응 부담 및 우선순위 조정", nextAction: "기관별 담당 재배분" },
  ],
};

const nav = [
  { id: "dashboard" as Tab, label: "대시보드", icon: "grid" },
  { id: "goals" as Tab, label: "성과 목표", icon: "target" },
  { id: "interviews" as Tab, label: "면담 관리", icon: "chat" },
  { id: "members" as Tab, label: "팀원 현황", icon: "users" },
];

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  const paths: Record<string, React.ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></>,
    target: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></>,
    chat: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M5 19h14"/></>,
    upload: <><path d="M12 16V4m0 0 4 4m-4-4-4 4"/><path d="M5 20h14"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    alert: <><path d="M10.3 3.7 2.2 18a2 2 0 0 0 1.7 3h16.2a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></>,
    arrow: <path d="m9 18 6-6-6-6"/>,
    close: <path d="M18 6 6 18M6 6l12 12"/>,
    more: <><circle cx="5" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="19" cy="12" r="1" fill="currentColor"/></>,
    trash: <><path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v5M14 11v5"/></>,
  };
  return <svg {...common}>{paths[name] ?? paths.grid}</svg>;
}

function Avatar({ member, large = false }: { member: Member; large?: boolean }) {
  return <span className={`avatar avatar-${member.color} ${large ? "avatar-large" : ""}`}>{member.name.slice(0, 1)}</span>;
}

function parseDate(value: string) {
  if (/Z$|[+-]\d{2}:\d{2}$/.test(value)) return new Date(value);
  if (value.length === 10) return new Date(`${value}T00:00:00+09:00`);
  return new Date(`${value}:00+09:00`);
}

function seoulDateParts(value: string) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Seoul", month: "numeric", day: "numeric" }).formatToParts(parseDate(value));
  return { month: Number(parts.find((p) => p.type === "month")?.value), day: Number(parts.find((p) => p.type === "day")?.value) };
}

function formatDate(value: string, withTime = false) {
  const d = parseDate(value);
  const base = new Intl.DateTimeFormat("ko-KR", { timeZone: "Asia/Seoul", month: "short", day: "numeric", weekday: "short" }).format(d);
  if (!withTime) return base;
  return `${base} ${new Intl.DateTimeFormat("ko-KR", { timeZone: "Asia/Seoul", hour: "2-digit", minute: "2-digit", hour12: false }).format(d)}`;
}

function StatusPill({ status }: { status: GoalStatus | InterviewStatus }) {
  return <span className={`status status-${status}`}>{status}</span>;
}

export default function Home() {
  const [data, setData] = useState<AppData>(seedData);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>("dashboard");
  const [search, setSearch] = useState("");
  const [memberFilter, setMemberFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [modal, setModal] = useState<"goal" | "interview" | "settings" | null>(null);
  const [selectedMember, setSelectedMember] = useState<number | null>(null);
  const [toast, setToast] = useState("");
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { setData(JSON.parse(saved)); } catch { /* keep safe demo data */ }
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data, ready]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2400);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const memberMap = useMemo(() => new Map(data.members.map((m) => [m.id, m])), [data.members]);
  const avgProgress = Math.round(data.goals.reduce((sum, g) => sum + g.progress, 0) / Math.max(data.goals.length, 1));
  const completeCount = data.goals.filter((g) => g.status === "종결").length;
  const atRisk = data.goals.filter((g) => g.progress < 30 && g.status !== "종결");
  const upcoming = data.interviews.filter((i) => i.status === "예정").sort((a, b) => a.date.localeCompare(b.date));

  const filteredGoals = data.goals.filter((g) => {
    const member = memberMap.get(g.memberId);
    const text = `${g.title} ${g.category} ${member?.name ?? ""}`.toLowerCase();
    return text.includes(search.toLowerCase()) && (memberFilter === "all" || String(g.memberId) === memberFilter) && (statusFilter === "all" || g.status === statusFilter);
  });

  const filteredInterviews = data.interviews.filter((i) => {
    const member = memberMap.get(i.memberId);
    const text = `${member?.name ?? ""} ${i.type} ${i.summary}`.toLowerCase();
    return text.includes(search.toLowerCase()) && (memberFilter === "all" || String(i.memberId) === memberFilter) && (statusFilter === "all" || i.status === statusFilter);
  }).sort((a, b) => b.date.localeCompare(a.date));

  const notify = (message: string) => setToast(message);

  function addGoal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const progress = Number(form.get("progress"));
    const goal: Goal = {
      id: Date.now(), memberId: Number(form.get("memberId")), title: String(form.get("title")),
      category: String(form.get("category")), status: String(form.get("status")) as GoalStatus,
      progress, dueDate: String(form.get("dueDate")), weight: Number(form.get("weight")), note: String(form.get("note")),
    };
    setData((prev) => ({ ...prev, goals: [goal, ...prev.goals] }));
    setModal(null); notify("새 성과 목표를 등록했습니다.");
  }

  function addInterview(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const interview: Interview = {
      id: Date.now(), memberId: Number(form.get("memberId")), date: `${String(form.get("date"))}:00+09:00`,
      type: String(form.get("type")), status: String(form.get("status")) as InterviewStatus,
      summary: String(form.get("summary")), nextAction: String(form.get("nextAction")),
    };
    setData((prev) => ({ ...prev, interviews: [interview, ...prev.interviews] }));
    setModal(null); notify("면담 일정을 저장했습니다.");
  }

  function cycleGoal(goal: Goal) {
    const next: GoalStatus = goal.status === "미진행" ? "진행" : goal.status === "진행" ? "종결" : "미진행";
    setData((prev) => ({ ...prev, goals: prev.goals.map((g) => g.id === goal.id ? { ...g, status: next, progress: next === "종결" ? 100 : g.progress } : g) }));
    notify(`상태를 '${next}'으로 변경했습니다.`);
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a"); link.href = url; link.download = `성과면담관리_백업_${new Date().toISOString().slice(0, 10)}.json`; link.click();
    URL.revokeObjectURL(url); notify("백업 파일을 내려받았습니다.");
  }

  function exportCsv() {
    const rows = [["팀원", "소속", "직무", "성과목표", "구분", "상태", "진척률", "기한", "가중치"], ...data.goals.map((g) => {
      const m = memberMap.get(g.memberId); return [m?.name ?? "", m?.team ?? "", m?.role ?? "", g.title, g.category, g.status, `${g.progress}%`, g.dueDate, `${g.weight}%`];
    })];
    const csv = "\ufeff" + rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = `성과현황_${new Date().toISOString().slice(0, 10)}.csv`; link.click(); URL.revokeObjectURL(url);
    notify("성과 현황 CSV를 내려받았습니다.");
  }

  function importJson(file?: File) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!Array.isArray(parsed.members) || !Array.isArray(parsed.goals) || !Array.isArray(parsed.interviews)) throw new Error();
        setData(parsed); notify("백업 데이터를 불러왔습니다."); setModal(null);
      } catch { notify("올바른 백업 파일이 아닙니다."); }
    };
    reader.readAsText(file);
  }

  const title = nav.find((item) => item.id === tab)?.label ?? "대시보드";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">H</span><span><b>HR FLOW</b><small>성과·면담 관리</small></span></div>
        <nav aria-label="주요 메뉴">
          {nav.map((item) => <button key={item.id} className={tab === item.id ? "active" : ""} onClick={() => { setTab(item.id); setSearch(""); setMemberFilter("all"); setStatusFilter("all"); }}><Icon name={item.icon}/><span>{item.label}</span>{item.id === "interviews" && upcoming.length > 0 && <em>{upcoming.length}</em>}</button>)}
        </nav>
        <div className="sidebar-bottom">
          <button onClick={() => setModal("settings")}><Icon name="download"/><span>데이터 관리</span></button>
          <div className="admin-profile"><span className="admin-avatar">관</span><span><b>관리자</b><small>관리자 시험판</small></span></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div><div className="eyebrow">2026년 하반기</div><h1>{title}</h1></div>
          <div className="top-actions"><span className="save-chip"><i/> 이 브라우저에 자동 저장</span><button className="icon-button" onClick={() => setModal("settings")} aria-label="데이터 관리"><Icon name="more"/></button><button className="primary" onClick={() => setModal(tab === "interviews" ? "interview" : "goal")}><Icon name="plus" size={18}/>{tab === "interviews" ? "면담 등록" : "목표 등록"}</button></div>
        </header>

        {tab === "dashboard" && <section className="content dashboard-view">
          <div className="welcome"><div><span className="demo-label">ADMIN PREVIEW</span><h2>팀의 흐름을 한눈에 확인하세요.</h2><p>목표 진척과 예정된 면담, 지원이 필요한 항목을 모았습니다.</p></div><button className="ghost-white" onClick={() => setTab("goals")}>전체 성과 보기 <Icon name="arrow" size={17}/></button></div>
          <div className="metric-grid">
            <Metric label="등록 성과" value={`${data.goals.length}개`} sub={`팀원 ${data.members.length}명`} icon="target" tone="red" />
            <Metric label="평균 진척률" value={`${avgProgress}%`} sub="전체 목표 기준" icon="grid" tone="blue" progress={avgProgress} />
            <Metric label="완료 성과" value={`${completeCount}개`} sub={`완료율 ${Math.round(completeCount / Math.max(data.goals.length, 1) * 100)}%`} icon="check" tone="green" />
            <Metric label="확인 필요" value={`${atRisk.length}개`} sub="진척률 30% 미만" icon="alert" tone="amber" />
          </div>
          <div className="dashboard-grid">
            <article className="panel wide"><PanelHeader title="팀원별 평균 진척률" desc="등록된 성과 목표의 단순 평균" action="성과 관리" onAction={() => setTab("goals")}/><div className="member-progress-list">
              {data.members.map((member) => {
                const goals = data.goals.filter((g) => g.memberId === member.id); const avg = Math.round(goals.reduce((s, g) => s + g.progress, 0) / Math.max(goals.length, 1));
                return <button key={member.id} className="member-progress" onClick={() => { setMemberFilter(String(member.id)); setTab("goals"); }}><Avatar member={member}/><span className="member-meta"><b>{member.name}</b><small>{member.team} · 목표 {goals.length}개</small></span><span className="bar"><i style={{ width: `${avg}%` }}/></span><strong>{avg}%</strong></button>;
              })}
            </div></article>
            <article className="panel"><PanelHeader title="다가오는 면담" desc="예정된 1:1 일정" action="전체 보기" onAction={() => setTab("interviews")}/><div className="upcoming-list">
              {upcoming.slice(0, 3).map((item) => { const member = memberMap.get(item.memberId)!; const parts = seoulDateParts(item.date); return <div className="upcoming-item" key={item.id}><div className="date-tile"><b>{parts.day}</b><small>{parts.month}월</small></div><div><b>{member.name} · {item.type}</b><small>{formatDate(item.date, true)}<br/>{item.summary}</small></div></div>; })}
              {upcoming.length === 0 && <Empty text="예정된 면담이 없습니다."/>}
            </div><button className="full-outline" onClick={() => setModal("interview")}><Icon name="plus" size={16}/> 새 면담 일정</button></article>
            <article className="panel wide"><PanelHeader title="확인 필요한 성과" desc="진척률이 낮거나 기한이 가까운 항목" action="전체 보기" onAction={() => setTab("goals")}/><div className="compact-table">
              {atRisk.map((goal) => { const member = memberMap.get(goal.memberId)!; return <button key={goal.id} onClick={() => { setMemberFilter(String(goal.memberId)); setTab("goals"); }}><Avatar member={member}/><span><b>{goal.title}</b><small>{member.name} · {goal.category}</small></span><span className="due">{formatDate(goal.dueDate)} 마감</span><strong>{goal.progress}%</strong><Icon name="arrow" size={16}/></button>; })}
              {atRisk.length === 0 && <Empty text="확인이 필요한 성과가 없습니다."/>}
            </div></article>
            <article className="panel data-panel"><div className="data-icon"><Icon name="download"/></div><h3>데이터 백업</h3><p>현재 입력 내용을 파일로 저장해 다른 PC에서도 이어서 사용할 수 있습니다.</p><div className="button-pair"><button onClick={exportJson}>백업 저장</button><button onClick={() => importRef.current?.click()}>불러오기</button></div></article>
          </div>
        </section>}

        {tab === "goals" && <section className="content">
          <Toolbar search={search} onSearch={setSearch} memberFilter={memberFilter} onMember={setMemberFilter} statusFilter={statusFilter} onStatus={setStatusFilter} members={data.members} statuses={["미진행", "진행", "종결"]} onExport={exportCsv}/>
          <div className="table-card"><div className="table-summary"><span>총 <b>{filteredGoals.length}</b>개 목표</span><span className="legend"><i className="dot red"/> 미진행 <i className="dot blue"/> 진행 <i className="dot green"/> 종결</span></div><div className="responsive-table"><table><thead><tr><th>담당자</th><th>성과 목표</th><th>상태</th><th>진척률</th><th>기한</th><th>가중치</th><th/></tr></thead><tbody>
            {filteredGoals.map((goal) => { const member = memberMap.get(goal.memberId)!; return <tr key={goal.id}><td><div className="person-cell"><Avatar member={member}/><span><b>{member.name}</b><small>{member.role}</small></span></div></td><td><div className="goal-cell"><b>{goal.title}</b><small>{goal.category} · {goal.note}</small></div></td><td><button className="plain" onClick={() => cycleGoal(goal)} title="클릭하여 상태 변경"><StatusPill status={goal.status}/></button></td><td><div className="progress-cell"><span className="bar"><i style={{ width: `${goal.progress}%` }}/></span><b>{goal.progress}%</b></div></td><td>{formatDate(goal.dueDate)}</td><td>{goal.weight}%</td><td><button className="icon-button subtle" aria-label="성과 삭제" onClick={() => { setData((p) => ({ ...p, goals: p.goals.filter((g) => g.id !== goal.id) })); notify("목표를 삭제했습니다."); }}><Icon name="trash" size={17}/></button></td></tr>; })}
          </tbody></table>{filteredGoals.length === 0 && <Empty text="조건에 맞는 성과 목표가 없습니다."/>}</div></div>
        </section>}

        {tab === "interviews" && <section className="content">
          <Toolbar search={search} onSearch={setSearch} memberFilter={memberFilter} onMember={setMemberFilter} statusFilter={statusFilter} onStatus={setStatusFilter} members={data.members} statuses={["예정", "완료"]}/>
          <div className="interview-layout"><article className="panel calendar-panel"><PanelHeader title="7월 면담 캘린더" desc="2026년 7월 일정"/><Calendar interviews={data.interviews} memberMap={memberMap}/></article><article className="panel interview-list-panel"><PanelHeader title="면담 일정 및 기록" desc={`${filteredInterviews.length}건`}/><div className="interview-cards">
            {filteredInterviews.map((item) => { const member = memberMap.get(item.memberId)!; return <div className="interview-card" key={item.id}><div className="interview-card-top"><div className="person-cell"><Avatar member={member}/><span><b>{member.name}</b><small>{member.team} · {item.type}</small></span></div><StatusPill status={item.status}/></div><div className="interview-date"><Icon name="calendar" size={16}/>{formatDate(item.date, true)}</div><h4>{item.summary}</h4><p><b>다음 행동</b>{item.nextAction || "등록된 후속 행동 없음"}</p><div className="card-actions">{item.status === "예정" && <button onClick={() => { setData((p) => ({ ...p, interviews: p.interviews.map((i) => i.id === item.id ? { ...i, status: "완료" } : i) })); notify("면담을 완료 처리했습니다."); }}><Icon name="check" size={15}/> 완료 처리</button>}<button className="danger-link" onClick={() => { setData((p) => ({ ...p, interviews: p.interviews.filter((i) => i.id !== item.id) })); notify("면담 기록을 삭제했습니다."); }}>삭제</button></div></div>; })}
            {filteredInterviews.length === 0 && <Empty text="조건에 맞는 면담 기록이 없습니다."/>}
          </div></article></div>
        </section>}

        {tab === "members" && <section className="content"><div className="section-intro"><div><h2>팀원별 성과와 면담 현황</h2><p>팀원을 선택하면 연결된 목표와 최근 면담을 빠르게 확인할 수 있습니다.</p></div></div><div className="member-card-grid">
          {data.members.map((member) => { const goals = data.goals.filter((g) => g.memberId === member.id); const interviews = data.interviews.filter((i) => i.memberId === member.id); const avg = Math.round(goals.reduce((s, g) => s + g.progress, 0) / Math.max(goals.length, 1)); return <article className={`member-card ${selectedMember === member.id ? "selected" : ""}`} key={member.id} onClick={() => setSelectedMember(selectedMember === member.id ? null : member.id)}><div className="member-card-head"><Avatar member={member} large/><div><h3>{member.name}</h3><p>{member.team} · {member.role}</p></div><Icon name="arrow"/></div><div className="member-stats"><span><small>평균 진척</small><b>{avg}%</b></span><span><small>성과 목표</small><b>{goals.length}</b></span><span><small>면담 기록</small><b>{interviews.length}</b></span></div><div className="big-bar"><i style={{ width: `${avg}%` }}/></div>{selectedMember === member.id && <div className="member-detail"><h4>등록 목표</h4>{goals.map((goal) => <button key={goal.id} onClick={(e) => { e.stopPropagation(); setMemberFilter(String(member.id)); setTab("goals"); }}><StatusPill status={goal.status}/><span>{goal.title}</span><b>{goal.progress}%</b></button>)}<button className="member-detail-action" onClick={(e) => { e.stopPropagation(); setMemberFilter(String(member.id)); setTab("interviews"); }}>면담 기록 보기 <Icon name="arrow" size={15}/></button></div>}</article>; })}
        </div></section>}
      </main>

      <input ref={importRef} hidden type="file" accept="application/json" onChange={(e) => importJson(e.target.files?.[0])}/>
      {modal && <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setModal(null)}><div className="modal" role="dialog" aria-modal="true"><button className="modal-close" onClick={() => setModal(null)} aria-label="닫기"><Icon name="close"/></button>
        {modal === "goal" && <GoalForm members={data.members} onSubmit={addGoal}/>} {modal === "interview" && <InterviewForm members={data.members} onSubmit={addInterview}/>} {modal === "settings" && <div><div className="modal-title"><span className="modal-icon"><Icon name="download"/></span><div><h2>데이터 관리</h2><p>브라우저에 저장된 시험판 데이터를 관리합니다.</p></div></div><div className="setting-stack"><button onClick={exportJson}><Icon name="download"/><span><b>전체 백업 저장</b><small>성과·면담·팀원 데이터를 JSON 파일로 저장</small></span><Icon name="arrow"/></button><button onClick={exportCsv}><Icon name="download"/><span><b>성과 현황 CSV 내보내기</b><small>엑셀에서 바로 열 수 있는 형식</small></span><Icon name="arrow"/></button><button onClick={() => importRef.current?.click()}><Icon name="upload"/><span><b>백업 불러오기</b><small>다른 PC에서 저장한 JSON 파일 복원</small></span><Icon name="arrow"/></button><button className="reset" onClick={() => { setData(seedData); setModal(null); notify("샘플 데이터로 초기화했습니다."); }}><Icon name="trash"/><span><b>샘플 데이터로 초기화</b><small>현재 입력 내용은 삭제됩니다.</small></span><Icon name="arrow"/></button></div><div className="privacy-note"><Icon name="alert" size={18}/><p><b>시험판 저장 방식</b><br/>데이터는 현재 사용 중인 브라우저에만 저장됩니다. 실제 인사정보 운영 전에는 로그인과 서버 데이터베이스 연결이 필요합니다.</p></div></div>}
      </div></div>}
      {toast && <div className="toast"><Icon name="check" size={18}/>{toast}</div>}
    </div>
  );
}

function Metric({ label, value, sub, icon, tone, progress }: { label: string; value: string; sub: string; icon: string; tone: string; progress?: number }) {
  return <article className="metric"><span className={`metric-icon ${tone}`}><Icon name={icon}/></span><div><small>{label}</small><strong>{value}</strong><p>{sub}</p></div>{progress !== undefined && <div className="ring" style={{ background: `conic-gradient(#e32636 ${progress * 3.6}deg, #f0f1f4 0deg)` }}><span>{progress}</span></div>}</article>;
}

function PanelHeader({ title, desc, action, onAction }: { title: string; desc?: string; action?: string; onAction?: () => void }) {
  return <div className="panel-header"><div><h3>{title}</h3>{desc && <p>{desc}</p>}</div>{action && <button onClick={onAction}>{action}<Icon name="arrow" size={15}/></button>}</div>;
}

function Empty({ text }: { text: string }) { return <div className="empty"><span><Icon name="grid"/></span><p>{text}</p></div>; }

function Toolbar({ search, onSearch, memberFilter, onMember, statusFilter, onStatus, members, statuses, onExport }: { search: string; onSearch: (v: string) => void; memberFilter: string; onMember: (v: string) => void; statusFilter: string; onStatus: (v: string) => void; members: Member[]; statuses: string[]; onExport?: () => void }) {
  return <div className="toolbar"><label className="search-box"><Icon name="search" size={18}/><input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="이름 또는 내용 검색"/></label><select value={memberFilter} onChange={(e) => onMember(e.target.value)}><option value="all">전체 팀원</option>{members.map((m) => <option value={m.id} key={m.id}>{m.name}</option>)}</select><select value={statusFilter} onChange={(e) => onStatus(e.target.value)}><option value="all">전체 상태</option>{statuses.map((s) => <option key={s}>{s}</option>)}</select><span className="toolbar-spacer"/>{onExport && <button className="outline-button" onClick={onExport}><Icon name="download" size={17}/> CSV 내보내기</button>}</div>;
}

function GoalForm({ members, onSubmit }: { members: Member[]; onSubmit: (e: FormEvent<HTMLFormElement>) => void }) {
  return <form onSubmit={onSubmit}><div className="modal-title"><span className="modal-icon"><Icon name="target"/></span><div><h2>새 성과 목표</h2><p>팀원의 목표와 진행 기준을 등록합니다.</p></div></div><div className="form-grid"><label>담당자<select name="memberId" required>{members.map((m) => <option value={m.id} key={m.id}>{m.name} · {m.role}</option>)}</select></label><label>성과 구분<select name="category"><option>핵심성과</option><option>사업성과</option><option>업무개선</option><option>역량개발</option></select></label><label className="full">목표명<input name="title" required placeholder="측정 가능한 목표를 입력하세요"/></label><label>상태<select name="status"><option>미진행</option><option>진행</option><option>종결</option></select></label><label>진척률 (%)<input name="progress" type="number" min="0" max="100" defaultValue="0" required/></label><label>기한<input name="dueDate" type="date" defaultValue="2026-08-31" required/></label><label>가중치 (%)<input name="weight" type="number" min="0" max="100" defaultValue="20" required/></label><label className="full">성과 기준·메모<textarea name="note" rows={3} placeholder="완료 기준이나 확인할 내용을 입력하세요"/></label></div><div className="modal-actions"><button type="button" onClick={() => (document.querySelector(".modal-close") as HTMLButtonElement)?.click()}>취소</button><button className="primary" type="submit">목표 등록</button></div></form>;
}

function InterviewForm({ members, onSubmit }: { members: Member[]; onSubmit: (e: FormEvent<HTMLFormElement>) => void }) {
  return <form onSubmit={onSubmit}><div className="modal-title"><span className="modal-icon"><Icon name="chat"/></span><div><h2>면담 일정·기록 등록</h2><p>예정된 면담과 완료된 기록을 함께 관리합니다.</p></div></div><div className="form-grid"><label>팀원<select name="memberId" required>{members.map((m) => <option value={m.id} key={m.id}>{m.name} · {m.team}</option>)}</select></label><label>면담 구분<select name="type"><option>정기 1:1</option><option>성장 면담</option><option>성과 면담</option><option>수시 면담</option></select></label><label>일시<input name="date" type="datetime-local" defaultValue="2026-07-24T10:00" required/></label><label>상태<select name="status"><option>예정</option><option>완료</option></select></label><label className="full">주요 내용<input name="summary" required placeholder="논의 주제 또는 면담 요약"/></label><label className="full">다음 행동<textarea name="nextAction" rows={3} placeholder="담당자와 기한이 드러나게 적어보세요"/></label></div><div className="modal-actions"><button type="button" onClick={() => (document.querySelector(".modal-close") as HTMLButtonElement)?.click()}>취소</button><button className="primary" type="submit">저장</button></div></form>;
}

function Calendar({ interviews, memberMap }: { interviews: Interview[]; memberMap: Map<number, Member> }) {
  const blanks = 3; const days = Array.from({ length: 31 }, (_, i) => i + 1);
  return <div className="calendar"><div className="weekdays">{["일", "월", "화", "수", "목", "금", "토"].map((d) => <span key={d}>{d}</span>)}</div><div className="days">{Array.from({ length: blanks }, (_, i) => <span className="day muted" key={`b${i}`}/>) }{days.map((day) => { const items = interviews.filter((i) => { const parts = seoulDateParts(i.date); return parts.month === 7 && parts.day === day; }); return <span className={`day ${day === 21 ? "today" : ""}`} key={day}><b>{day}</b>{items.slice(0, 2).map((i) => <em className={i.status === "완료" ? "done" : ""} key={i.id}>{memberMap.get(i.memberId)?.name} {i.type}</em>)}</span>; })}</div></div>;
}
