import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "성과·면담 관리 | 관리자 시험판",
  description: "팀 성과 목표와 면담 일정을 한눈에 관리하는 관리자용 시험판",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
