# Netlify 배포 안내

## 방법 A — 완성 폴더 바로 올리기

개발 작업 없이 가장 빠르게 배포하는 방법입니다.

1. 전달받은 ZIP 파일의 압축을 풉니다.
2. [Netlify Drop](https://app.netlify.com/drop)에 접속합니다.
3. 압축을 푼 `netlify-drop` 폴더를 화면에 끌어다 놓습니다.
4. 배포가 끝나면 발급된 주소를 열어 확인합니다.
5. Netlify의 **Site configuration → Change site name**에서 주소 이름을 바꿀 수 있습니다.

`netlify-drop` 폴더 안에는 `index.html`, `_assets`, `_redirects` 등 실행에 필요한 완성 파일이 포함됩니다. 이 폴더 내부 파일을 따로 수정할 필요는 없습니다.

## 방법 B — GitHub 연결

이후 코드를 계속 수정할 계획이라면 프로젝트 전체를 GitHub에 올린 뒤 Netlify에 저장소를 연결합니다.

| 설정 | 값 |
| --- | --- |
| Build command | `npm run build:netlify` |
| Publish directory | `netlify-drop` |
| Node version | `22.13.0` |

루트의 `netlify.toml`에 위 설정이 이미 들어 있어 보통은 별도 입력이 필요 없습니다.

## 배포 후 확인할 항목

- 대시보드와 각 좌측 메뉴가 정상적으로 열리는지
- 목표 등록 후 새로고침해도 입력 내용이 유지되는지
- 면담 등록·완료 처리가 되는지
- JSON 백업과 CSV 내보내기가 동작하는지
- PC와 휴대폰에서 메뉴와 표가 잘 보이는지

## 중요한 제한

이 시험판은 각 사용자의 브라우저에만 데이터를 저장합니다. URL을 여러 명에게 공유해도 서로의 입력 내용은 합쳐지지 않습니다. 공동 사용, 계정 로그인, 직원별 권한이 필요하면 Supabase 연결 버전으로 전환해야 합니다.
